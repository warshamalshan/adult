# Photo Manifest

The following image URLs were found in the supplied HTML and mapped to local files.

| Source URL | Local Path |
|---|---|
| https://woodcapitol.com/wp-content/uploads/2025/01/Solid-Wood-Table-made-from-Solid-Wood-Slabs.jpg | `assets/photos/Solid-Wood-Table-made-from-Solid-Wood-Slabs.jpg` |
| https://woodcapitol.com/wp-content/uploads/2023/03/Solid-Wood-Slabs-Specialist-1024x768.jpg | `assets/photos/Solid-Wood-Slabs-Specialist-1024x768.jpg` |
| https://woodcapitol.com/wp-content/uploads/2022/11/Wood-Capitol-Favicon-280x280-1.png | `assets/photos/Woodpecker-Favicon-280x280-1.png` |
| https://woodcapitol.com/wp-content/uploads/2025/01/Solid-Wood-Table.jpg | `assets/photos/Solid-Wood-Table.jpg` |
| https://woodcapitol.com/wp-content/uploads/2022/11/Wood_Capitol_Sticker-1400x156-1.png | `assets/photos/Woodpecker_Sticker-1400x156-1.png` |
| https://woodcapitol.com/wp-content/uploads/2022/11/Wood-Capitol-Favicon-280x280-1-100x100.png | `assets/photos/Woodpecker-Favicon-280x280-1-100x100.png` |
| https://woodcapitol.com/wp-content/uploads/2023/01/Solid-Wood-Restoration.jpg | `assets/photos/Solid-Wood-Restoration.jpg` |
| https://woodcapitol.com/wp-content/uploads/2023/07/In-House-Carpentry.jpg | `assets/photos/In-House-Carpentry.jpg` |
| https://woodcapitol.com/wp-content/uploads/2026/03/home_img-2.png | `assets/photos/home_img-2.png` |
| https://woodcapitol.com/wp-content/uploads/2026/03/home_img-2-300x197.png | `assets/photos/home_img-2-300x197.png` |
| https://woodcapitol.com/wp-content/uploads/2026/03/home_img-2-600x393.png | `assets/photos/home_img-2-600x393.png` |
| https://woodcapitol.com/wp-content/uploads/2026/03/Rectangle-62.jpg | `assets/photos/Rectangle-62.jpg` |
| https://woodcapitol.com/wp-content/uploads/2026/03/Rectangle-62-300x238.jpg | `assets/photos/Rectangle-62-300x238.jpg` |
| https://woodcapitol.com/wp-content/uploads/2026/03/Rectangle-62-600x477.jpg | `assets/photos/Rectangle-62-600x477.jpg` |
