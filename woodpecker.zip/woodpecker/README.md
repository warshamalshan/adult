# Woodpecker

This repository contains a static HTML page renamed to **Woodpecker** from the supplied source content. The primary code file is `index.html`, and the photo assets are stored under `assets/photos/`.

## Files

| Path | Purpose |
|---|---|
| `index.html` | GitHub-ready static HTML page with the site name changed to **Woodpecker**. |
| `assets/photos/` | Local photo files used by the page. |
| `PHOTO_MANIFEST.md` | Mapping of original photo URLs to local asset paths. |

## How to view

Open `index.html` directly in a browser, or publish this repository with GitHub Pages by selecting the repository root as the Pages source.
